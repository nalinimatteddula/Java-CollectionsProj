package collectionproj;

import java.util.ArrayList;
import java.util.LinkedList;

public class Test {

	public static void main(String[] args) {
		
		LinkedList<String> names = new LinkedList<String>();
		names.add("Hary");
		names.add("potter");
		names.add("jenny");
		names.add("david");
		
		LinkedList<String> names2 = new LinkedList<String>();
		names2.add("john");
		names2.add("kelvin");
		names2.add("Hary");
		names2.add("potter");
		names2.add("preeti");
		System.out.println(names);
		
		//names.addAll(names2);
		
		//names.removeAll(names2);
		//names.retainAll(names2);
		//names.clear();
//		for(String str : names) {
//			System.out.println(str);
//		}
		
//		String[] namesArr = new String[names.size()];
//		
//		names.toArray(namesArr);
//			for (String str : namesArr) {
//				System.out.println(str);
//		}
//		Object[] objectsArr = names.toArray();
//		for (Object obj : objectsArr) {
//			System.out.println(obj);
//		}
		//System.out.println(names.size());
		//System.out.println(names.contains("potter"));
       
//		for (String str : names) {
//			System.out.println(str);
//		}
		
	}

}
