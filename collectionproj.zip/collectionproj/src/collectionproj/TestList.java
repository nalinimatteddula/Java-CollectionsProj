package collectionproj;

import java.util.*;

public class TestList {

	public static void main(String[] args) {
		
		LinkedList<String> names = new LinkedList<String>();
		names.add("Hary");
		names.add("Raj");
		names.add("Kumar");
		names.add("john");
		names.add("Madhuri");
		names.add("Archana");
		names.add("Kumar");
		names.add("Raj");
		names.add("Amir");
		
		Collections.sort(names);
		
    // System.out.println(names.get(2));
		
		//System.out.println(names.set(1,"rahul"));
		
		//names.add(1,"preeti");
		
		//System.out.println(names.indexOf("Kumar"));
		System.out.println(names.lastIndexOf("Kumar"));
		for (String str : names) {
			System.out.println(str);
		}
		
	}

}
