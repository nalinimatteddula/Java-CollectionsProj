package collectionproj;

import java.util.ArrayList;
import java.util.LinkedList;

public class TestStore {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Customer c1 = new Customer(1,"sailu","AP");
		Customer c2 = new Customer(1,"preeti","TN");
		Customer c3 = new Customer(1,"rahul","AP");
		Customer c4 = new Customer(1,"revanth","AP");
		Customer c5 = new Customer(1,"pavan","AP");
		
		ArrayList<Customer> customerList = new ArrayList<Customer>();
		customerList.add(c1);
		customerList.add(c2);
		customerList.add(c3);
		customerList.add(c4);
		customerList.add(c5);
	
		
		
		
	}

}
