package collectionproj;

import java.util.LinkedList;
import java.util.ListIterator;

public class TestListIterator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList<String> names = new LinkedList<String>();
		names.add("Hary");
		names.add("Raj");
		names.add("Kumar");
		names.add("john");
		names.add("Madhuri");
		names.add("Archana");
		names.add("Kumar");
		names.add("Raj");
		names.add("Amir");
		
		ListIterator<String> listIterator = names.listIterator();
        
		System.out.println(listIterator.hasPrevious());	
        
		listIterator.next();
		 //listIterator.next();
        listIterator.next();
        
        System.out.println(listIterator.previous());
	   
       // listIterator.set("Anil");
        listIterator.add("AnilKumar");
        System.out.println(names);
        
	}

}
