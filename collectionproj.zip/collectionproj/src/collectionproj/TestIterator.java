package collectionproj;

import java.util.LinkedList;

import java.util.Iterator;

public class TestIterator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList<String> names = new LinkedList<String>();
		names.add("Hary");
		names.add("potter");
		names.add("jenny");
		names.add("david");
		
		Iterator<String> iterator = names.iterator();
		//iterator.remove();
		iterator.next();
		iterator.remove();
		System.out.println(names);
//	while (iterator.hasNext()){
//		String str = iterator.next();
//		System.out.println(str);
//	}
	}

}
